#pragma once
#include "SoccerTeam.h"
#include "SSC2.h"
class Goal;
class PlayerBase;
class FieldPlayer2;
class SoccerPitch;
//class GoalKeeper;
//class SupportSpotCalculator2;

class SoccerTeam2 : public SoccerTeam  {

protected:
	//creates all the players for this team
	void CreatePlayers();

	//pointer to opponents
	SoccerTeam* m_pOpponents;
	//pointers to 'key' players
	FieldPlayer2*               m_pControllingPlayer;
	FieldPlayer2*               m_pSupportingPlayer;
	FieldPlayer2*               m_pReceivingPlayer;
	FieldPlayer2*               m_pPlayerClosestToBall;

	//the squared distance the closest player is from the ball
	double                     m_dDistSqToBallOfClosestPlayer;

	SSC2* m_pSupportSpotCalc;

public:
	//structure for the players
	std::vector<FieldPlayer2*>  m_Players;

	SoccerTeam2(Goal*        home_goal,
             Goal*        opponents_goal,
             SoccerPitch* pitch,
			 team_color   color);
	~SoccerTeam2(void);
	void initialize();
	//void setPlayerHomeRegion(int plyr, int region);
	void Update();
	void Render();
	void CalculateClosestPlayerToBall();
	std::vector<FieldPlayer2*> getPlayers()  {return m_Players;}
	FieldPlayer2* PlayerClosestToBall()const{return m_pPlayerClosestToBall;}

	//determines team
	int getColor()  {if(Color() == red)  return 0; return 1;}
	//gets opponents, useful for opponents that are extending soccerteam
	SoccerTeam*const getOpponents()const{return m_pOpponents;}
	//see above
	void SetOpponents(SoccerTeam* opps){m_pOpponents = opps;}
	//temporary method to make sure lostControl is being called on SoccerTeam2 rather than the parent method directly
	void lostControl() {SoccerTeam::LostControl();}
	//overrides that set a FieldPlayer2 rather than a PlayerBase
	void SetPlayerClosestToBall(FieldPlayer2* plyr){m_pPlayerClosestToBall=plyr;}
	void SetSupportingPlayer(FieldPlayer2* plyr){m_pSupportingPlayer = plyr;}
	void SetReceiver(FieldPlayer2* plyr){m_pReceivingPlayer = plyr;}
	void SetControllingPlayer(FieldPlayer2* plyr){m_pControllingPlayer = plyr;}
	FieldPlayer2* ControllingPlayer()  {return m_pControllingPlayer;}
	FieldPlayer2* getControllingPlayer()  {return m_pControllingPlayer;}

	bool  InControl()const{if(m_pControllingPlayer)return true; else return false;}
	void  LostControl(){m_pControllingPlayer = NULL;}
	Vector2D GetSupportSpot()const{return m_pSupportSpotCalc->GetBestSupportingSpot();}
	//void DetermineBestSupportingPosition()const{m_pSupportSpotCalc->DetermineBestSupportingPosition();}
	//const std::vector<FieldPlayer2*>& Members()const{return m_Players;} 
};
