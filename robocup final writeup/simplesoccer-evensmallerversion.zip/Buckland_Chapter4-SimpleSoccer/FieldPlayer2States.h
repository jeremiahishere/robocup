#ifndef FIELDPLAYERSTATES_H
#define FIELDPLAYERSTATES_H

//the structure of this file is based on FieldPlayerSates.h
#include "FieldPlayer2BaseState.h"
class FieldPlayer2;

class DefendMiddle : public FieldPlayer2BaseState  {
private:
	DefendMiddle(){}
public:
	static DefendMiddle* instance();
	void enter(FieldPlayer2* fp);
	void execute(FieldPlayer2* fp);
	void exit(FieldPlayer2* fp);
	std::string getName();
};

class DefendLeft : public FieldPlayer2BaseState  {
private:
	DefendLeft(){}
public:
	static DefendLeft* instance();
	void enter(FieldPlayer2* fp);
	void execute(FieldPlayer2* fp);
	void exit(FieldPlayer2* fp);
	std::string getName();
};

class DefendRight : public FieldPlayer2BaseState  {
private:
	DefendRight(){}
public:
	static DefendRight* instance();
	void enter(FieldPlayer2* fp);
	void execute(FieldPlayer2* fp);
	void exit(FieldPlayer2* fp);
	std::string getName();
};

//renamed because there was a naming conflict with ChaseBall for the fieldplayer
class ChaseBall2 : public FieldPlayer2BaseState  {
private:
	ChaseBall2(){}
public:
	static ChaseBall2* instance();
	void enter(FieldPlayer2* fp);
	void execute(FieldPlayer2* fp);
	void exit(FieldPlayer2* fp);
	std::string getName();
};

class HasBall : public FieldPlayer2BaseState  {
private:
	HasBall(){}
public:
	static HasBall* instance();
	void enter(FieldPlayer2* fp);
	void execute(FieldPlayer2* fp);
	void exit(FieldPlayer2* fp);
	std::string getName();
};

class SetupPass : public FieldPlayer2BaseState  {
private:
	SetupPass(){}
public:
	static SetupPass* instance();
	void enter(FieldPlayer2* fp);
	void execute(FieldPlayer2* fp);
	void exit(FieldPlayer2* fp);
	std::string getName();
};

class HoldPosition : public FieldPlayer2BaseState  {
private:
	HoldPosition()  {}
public:
	static HoldPosition* instance();
	void enter(FieldPlayer2* fp);
	void execute(FieldPlayer2* fp);
	void exit(FieldPlayer2* fp);
	std::string getName();
};
#endif