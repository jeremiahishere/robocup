#include "FieldPlayerstate.h"

FieldPlayerstate::FieldPlayerstate(void)
{
}

FieldPlayerstate::~FieldPlayerstate(void)
{
}
